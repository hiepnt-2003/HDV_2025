create definer = root@localhost trigger generate_invoice_number
    before insert
    on invoices
    for each row
BEGIN
    DECLARE next_number INT;
    DECLARE invoice_prefix VARCHAR(10);

    SET invoice_prefix = CONCAT('INV', DATE_FORMAT(NEW.issue_date, '%Y%m'));

    SELECT COALESCE(MAX(CAST(SUBSTRING(invoice_number, 10) AS UNSIGNED)), 0) + 1
    INTO next_number
    FROM invoices
    WHERE invoice_number LIKE CONCAT(invoice_prefix, '%');

    SET NEW.invoice_number = CONCAT(invoice_prefix, LPAD(next_number, 4, '0'));
END;

